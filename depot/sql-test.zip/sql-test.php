<?php
/* Créé par "Abogil", créer un fichier debug.php */ 

// Activer la journalisation des erreurs PHP 
error_reporting(E_ALL);

// ****** Configuration Début ****** 
$DBhost = "serveur"; // Adresse du serveur SQL 
$DBName = "nom"; // Nom de la base de données SQL 
$DBowner = "identifiant"; // Login du serveur SQL 
$DBpw = "motdepasse"; // Mot de passe du serveur SQL 
// ****** Configuration Fin ****** 
	 
try {
    // Connecter à la base de données
    $fh_db = mysqli_connect($DBhost, $DBowner, $DBpw, $DBName);
    if (!$fh_db) {
        throw new Exception('Erreur de connexion à la base de données : ' . mysqli_connect_error());
    } else {
    	echo "1- Connexion à la base de données = <strong> OK </strong> <br />\n";
		}
} catch (Exception $e) {
    echo "1- Erreur connexion à la base de données = <strong>" . $e->getMessage() . "</strong> <br /> <br />\n";
}

try {
    // Selectionner la base de données
    $sel = mysqli_select_db($fh_db, $DBName);
    if (!$sel) {
        throw new Exception('Erreur de sélection de la base de données : ' . mysqli_error($fh_db));
    } else {
    	echo "2- Accès à la base de données $DBName = <strong> OK </strong> <br />\n";
    }
} catch (Exception $e) {
    echo "2- Erreur accès à la base de données $DBName = <strong>" . $e->getMessage() . "</strong> <br /> <br />\n";
}
 
// Création de la table Tab_test_DB 
$sql_query="CREATE TABLE `Tab_test_DB` ( `Id` int(11) NOT NULL auto_increment, `NOM` varchar(32) NOT NULL default '', `PRENOM` varchar(32) NOT NULL default '', PRIMARY KEY (`Id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8";	 // Requête 
try {
    // Executer la requête
    $result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
    if (!$result_query) {
        throw new Exception('Erreur de création de la table : ' . mysqli_error($fh_db));
    } else {
        echo "3- Création de la table Tab_test_DB =<strong> OK </strong> <br /> \n";
    }
} catch (Exception $e) {
    echo "3- Erreur création de la table \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $e->getMessage() . "</strong> <br /> \n";
}

// Ajout d'un enregistrement 
$sql_query="INSERT INTO `Tab_test_DB` values ('','NONYME','Anne')";	 // Requête 
try {
    // Executer la requête
    $result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
    if (!$result_query) {
        throw new Exception('Erreur d\'ajout d\'enregistrement : ' . mysqli_error($fh_db));
    } else {
        echo "4- Ajout d'un enregistrement  =<strong> OK </strong> <br /> \n";
    }
} catch (Exception $e) {
    echo "4- Erreur ajout de valeur \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $e->getMessage() . "</strong> <br /> \n";
}

// Sélection dans la table Tab_test_DB 
$sql_query="SELECT Id, NOM, PRENOM FROM `Tab_test_DB` WHERE NOM LIKE 'NONYME'";	 // Requête 
try {
    // Executer la requête
    $result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
    if (!$result_query) {
        throw new Exception('Erreur de sélection des données : ' . mysqli_error($fh_db));
    } else {
   		echo "5- La colonne <strong>NOM</strong> contenant la valeur <strong>NONYME</strong> a été trouvée. <br /> \n";
    }
} catch (Exception $e) {
    echo "5- Erreur de sélection de valeur \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $e->getMessage() . "</strong> <br /> \n";
}

$sql_query="SELECT Id, NOM, PRENOM FROM `Tab_test_DB` ORDER BY NOM";	 // Requête 
try {
    // Executer la requête
    $result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
    if (!$result_query) {
        throw new Exception('Erreur de sélection des données : ' . mysqli_error($fh_db));
    }
    $result_count_row_get = mysqli_num_rows($result_query);	
} catch (Exception $e) {
    echo "5- Erreur de sélection de colonne \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $e->getMessage() . "</strong> <br /> \n";
}
echo "5- Nombre de résultats trouvés = <strong>$result_count_row_get</strong> [doit être égal à 1]<br /> \n"; 
mysqli_free_result($result_query);

// Suppression de la table Tab_test_DB 
$sql_query="DROP TABLE IF EXISTS `Tab_test_DB`";	 // Requête 
try {
    // Executer la requête
    $result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
    if (!$result_query) {
        throw new Exception('Erreur de suppression de la table : ' . mysqli_error($fh_db));
    } else {
        echo "6- Suppression de la table Tab_test_DB =<strong> OK </strong> <br /> \n";
        }
} catch (Exception $e) {
    echo "6- Erreur suppression de la table \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $e->getMessage() . "</strong> <br /> \n";
}

// Fermeture de la connexion 
mysqli_close($fh_db); 
?>