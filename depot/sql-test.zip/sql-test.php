<?php 
/* Par "Abogil", créez un fichier debug.php */ 

error_reporting(E_ALL);	// Activer le rapport d'erreurs PHP

// ****** Configuration - Debut ****** 
 $DBhost = "serveur"; // adresse du serveur SQL
 $DBName = "nom"; // nom de la base SQL
 $DBowner= "identifiant"; // identifiant SQL 
 $DBpw	 = "mdp"; // mot de passe SQL 
// ****** Configuration - Fin ****** 
	 
$fh_db = mysqli_connect($DBhost, $DBowner, $DBpw, $DBName); 
$Erreur = mysqli_connect_error($fh_db); 
if (strlen($Erreur) > 0) { echo "1- mysqli_connect Connexion a la DATABASE = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "1- mysqli_connect Connexion a la DATABASE = <strong> OK </strong> <br /> <br />\n"; }

$sel = mysqli_select_db($fh_db, $DBName); 
$Erreur = mysqli_error($sel); 
if (strlen($Erreur) > 0) { echo "2- mysqli_select_db Acces a la DATABASE $DBName = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "2- mysqli_select_db Acces a la DATABASE $DBName = <strong> OK </strong> <br /> <br />\n"; }

// Création de la table Tab_test_DB
$sql_query="CREATE TABLE `Tab_test_DB` ( `Id` int(11) NOT NULL auto_increment, `NOM` varchar(32) NOT NULL default '', `PRENOM` varchar(32) NOT NULL default '', PRIMARY KEY (`Id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8";	 // Requête 
$result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
$Erreur = mysqli_error(); 
echo "3- \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $result_query . "</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo "Creation de la table Tab_test_DB = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "Creation de la table Tab_test_DB = <strong> OK </strong> <br /> <br />\n"; }

// Ajout d'un enregistrement
$sql_query="INSERT INTO `Tab_test_DB` values ('','NONYME','Anne')";	 // Requête 
$result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête
$Erreur = mysqli_error(); 
echo "4- \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $result_query . "</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo " Ajout d'un enregistrement = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo " Ajout d'un enregistrement = <strong> OK </strong> <br /> <br />\n"; }

// SELECT dans la table Tab_test_DB
$sql_query="SELECT Id, NOM, PRENOM FROM `Tab_test_DB` WHERE NOM=\'NONYME\'";	 // Requête 
$result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
$Erreur = mysqli_error(); 
echo "5- \$sql_query=<strong>$sql_query</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo "SELECT dans la table Tab_test_DB = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "SELECT dans la table Tab_test_DB = <strong> OK </strong> <br /> \n"; }

$sql_query="SELECT Id, NOM, PRENOM FROM `Tab_test_DB` ORDER BY NOM";	 // Requête 
$result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
$result_count_row_get = mysqli_num_rows($result_query);	
$Erreur = mysqli_error(); 
echo "Nombre d'enregistrements trouves = <strong>$result_count_row_get</strong> <br /> <br /> \n"; 
if (strlen($Erreur) > 0)	exit; 
mysqli_free_result($result_query);

// Supression de la table Tab_test_DB
$sql_query="DROP TABLE IF EXISTS `Tab_test_DB`";	 // Requête 
$result_query=mysqli_query($fh_db, $sql_query);	 // Exécution de la requête 
$Erreur = mysqli_error(); 
echo "6- \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $result_query . "</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo "Supression de la table Tab_test_DB = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "Supression de la table Tab_test_DB = <strong> OK </strong> <br /> <br />\n"; }

// Closing connection 
mysqli_close($fh_db); 
?>