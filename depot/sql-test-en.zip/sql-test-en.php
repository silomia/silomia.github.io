<?php 
/* By "Abogil", create a file debug.php */ 

error_reporting(E_ALL);	// Enable PHP error reporting 

// ****** Configuration Start ****** 
 $DBhost = "server"; // SQL server address 
 $DBName = "name"; // SQL database name 
 $DBowner= "login"; // login SQL 
 $DBpw	 = "pwd"; // password SQL 
// ****** Configuration End ****** 
	 
$fh_db = mysqli_connect($DBhost, $DBowner, $DBpw, $DBName); 
$Erreur = mysqli_connect_error($fh_db); 
if (strlen($Erreur) > 0) { echo "1- mysqli_connect Connect to DATABASE = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "1- mysqli_connect Connect to DATABASE = <strong> OK </strong> <br /> <br />\n"; }

$sel = mysqli_select_db($fh_db, $DBName); 
$Erreur = mysqli_error($sel); 
if (strlen($Erreur) > 0) { echo "2- mysqli_select_db Access to DATABASE $DBName = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "2- mysqli_select_db Access to DATABASE $DBName = <strong> OK </strong> <br /> <br />\n"; }

// Creating table Tab_test_DB 
$sql_query="CREATE TABLE `Tab_test_DB` ( `Id` int(11) NOT NULL auto_increment, `NOM` varchar(32) NOT NULL default '', `PRENOM` varchar(32) NOT NULL default '', PRIMARY KEY (`Id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8";	 // Query 
$result_query=mysqli_query($fh_db, $sql_query);	 // Query execution 
$Erreur = mysqli_error(); 
echo "3- \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $result_query . "</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo "Creating table Tab_test_DB = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "Creating table Tab_test_DB = <strong> OK </strong> <br /> <br />\n"; }

// Adding a record 
$sql_query="INSERT INTO `Tab_test_DB` values ('','NONYME','Anne')";	 // Query 
$result_query=mysqli_query($fh_db, $sql_query);	 // Query execution 
$Erreur = mysqli_error(); 
echo "4- \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $result_query . "</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo "Adding a record = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "Adding a record = <strong> OK </strong> <br /> <br />\n"; }

// SELECT in table Tab_test_DB 
$sql_query="SELECT Id, NOM, PRENOM FROM `Tab_test_DB` WHERE NOM=\'NONYME\'";	 // Query 
$result_query=mysqli_query($fh_db, $sql_query);	 // Query execution 
$Erreur = mysqli_error(); 
echo "5- \$sql_query=<strong>$sql_query</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo "SELECT in table Tab_test_DB = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "SELECT in table Tab_test_DB = <strong> OK </strong> <br /> \n"; }

$sql_query="SELECT Id, NOM, PRENOM FROM `Tab_test_DB` ORDER BY NOM";	 // Query 
$result_query=mysqli_query($fh_db, $sql_query);	 // Query execution 
$result_count_row_get = mysqli_num_rows($result_query);	
$Erreur = mysqli_error(); 
echo "Number of results found = <strong>$result_count_row_get</strong> <br /> <br /> \n"; 
if (strlen($Erreur) > 0)	exit; 
mysqli_free_result($result_query);

// Removal of the table Tab_test_DB 
$sql_query="DROP TABLE IF EXISTS `Tab_test_DB`";	 // Query 
$result_query=mysqli_query($fh_db, $sql_query);	 // Query execution 
$Erreur = mysqli_error(); 
echo "6- \$sql_query=<strong>$sql_query</strong> <br /> \$result_query=<strong>" . $result_query . "</strong> <br /> \n"; 
if (strlen($Erreur) > 0) { echo "Removal of the table Tab_test_DB = <strong>" . $Erreur . "</strong> <br /> <br />\n"; exit; } 
else { echo "Removal of the table Tab_test_DB = <strong> OK </strong> <br /> <br />\n"; }

// Closing connection 
mysqli_close($fh_db); 
?>