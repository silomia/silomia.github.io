<?php
// TEST FUNCTION MAIL() PHP
// CREATE A FILE email.php

// *** To setup
$to = "adresse@machin.truc";  
$from  = "postmaster@bidule.truc";  

// *** Leave as is
$jour  = date("d-m-Y");
$heure = date("H:i");

$sujet = "Test Mail $jour $heure";

$contenu = "";
$contenu .= "<html> \n";
$contenu .= "<head> \n";
$contenu .= "<title> Subject </title> \n";
$contenu .= "</head> \n";
$contenu .= "<body> \n";
$contenu .= "Mail in simple HTML format with the PHP mail().<br> <b>$sujet </b> <br> \n";
$contenu .= "</body> \n";
$contenu .= "</HTML> \n";

$headers  = "MIME-Version: 1.0 \n";
$headers .= "Content-Transfer-Encoding: 8bit \n";
$headers .= "Content-type: text/html; charset=utf-8 \n";
$headers .= "From: $from  \n";
// $headers .= "Disposition-Notification-To: $from  \n"; // acknowledgement of receipt

$verif_envoi_mail = TRUE;

$verif_envoi_mail = @mail ($to, $sujet, $contenu, $headers);
 
if ($verif_envoi_mail === FALSE) echo " ### Verification Sending Mail=$verif_envoi_mail Error sending mail <br> \n";
else echo " *** Verification Sending Mail=$verif_envoi_mail Mail sent; avec succ&egrave;s de $to vers $from <br> with the subject: $sujet \n"; 
?>